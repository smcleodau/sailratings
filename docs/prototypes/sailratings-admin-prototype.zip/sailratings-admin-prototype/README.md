# SailRatings admin prototype (2 Sep 2026)

Clickable, single-file prototype of the rebuilt admin in the SailRatings design system with a Dusk ground. Open `index.html` in a browser. Live copy: https://claude.ai/code/artifact/a824629d-4bf3-4e9b-a73a-4c39978b68d9

- `index.html` — the prototype. All CSS/JS inline; Google Fonts (Saira Condensed, Libre Franklin, JetBrains Mono) are the only external requests. Hash routes: #overview #dupes #merges #corrections #health #tables #scrapers #sources #firecrawl #orders #users #billing #chat.
- `admin_data.json` — the data the page renders from: a snapshot of the dev DB (`_handovers/sailratings-admin-export-20260902`) plus the live Stripe account read on 2 Sep 2026. Not sample data.
- `build_data.py` — turns the DB export into `admin_data.json`. `build_html.py` — assembles `index.html` (tokens + CSS + screens + data).
- `screens/` — PNGs of Today, Duplicate boats, Scrapers, Orders, Users & plans.

Build from: `docs/specs/SPEC-22-Admin-Rebuild.md` (shell, design rules, endpoints), `SPEC-23` (customers zone), `SPEC-24` (scrapers/ops). The prototype is the visual contract; the specs are the data contract. Where they disagree, the spec wins.

Design rules embodied here: Dusk ramp surfaces (`--dusk-950 … --dusk-50`), Signal `#FF4119` only on ratings and one primary action per screen, JetBrains Mono for every number/label/id, typographic glyphs (no icon set), hairline borders, radii 6–16px, no shadows.
