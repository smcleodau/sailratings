import re, json
SRC='/tmp/claude-0/-home-claude/3d6b3780-45d8-5cd2-9972-1d08da93481c/scratchpad/sailratings-admin.html'
old=open(SRC).read()
style=re.search(r'<style>.*?</style>',old,re.S).group(0)
head=old[:old.index('<style>')]
data=open('/home/claude/admin_data.json').read()

extra_css="""
<style>
.cluster{padding:0;overflow:hidden}
.cluster .boats{display:grid;grid-template-columns:repeat(var(--n),minmax(0,1fr));}
.cluster .boat{padding:16px 18px;border-right:1px solid var(--border-subtle);display:flex;flex-direction:column;align-items:flex-start;gap:10px;min-width:0}
.cluster .boat .kv,.cluster .boat .name{align-self:stretch}
.cluster .boat:last-child{border-right:0}
.cluster .boat .name{font-family:var(--font-display);font-weight:700;font-size:20px;line-height:1;text-transform:uppercase;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cluster .boat .id{font-family:var(--font-data);font-size:10.5px;color:var(--sr-text-label);letter-spacing:.08em}
.cluster .boat.lead{background:rgba(196,187,240,0.035)}
.cluster .head{display:flex;align-items:center;gap:10px;padding:12px 18px;border-bottom:1px solid var(--border-subtle);background:var(--surface-deep)}
.cluster .head .key{font-family:var(--font-data);font-size:12px;color:var(--dusk-200);letter-spacing:.04em}
.cluster .head .why{margin-left:auto;font-family:var(--font-data);font-size:10.5px;color:var(--sr-text-label);letter-spacing:.08em}
.cluster .foot{border-top:1px solid var(--border-subtle);padding:12px 18px;display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.cluster .foot .hint{color:var(--sr-text-dim);font-size:12.5px;margin-right:auto}
.cluster select{background:var(--surface-page);border:1px solid var(--border-subtle);border-radius:var(--radius-sm);color:var(--sr-ink-on-dark);font-family:var(--font-data);font-size:11.5px;padding:6px 8px}
.tier{font-family:var(--font-data);font-weight:700;font-size:12px;padding:2px 8px;border-radius:4px;border:1px solid var(--border-strong)}
.tier.B{color:var(--sr-buoy);border-color:rgba(232,178,58,.45)}.tier.D{color:var(--sr-text-dim)}
.meter{display:grid;grid-template-columns:150px 1fr 48px;gap:8px 12px;align-items:center;font-size:12.5px}
.meter .k{font-family:var(--font-data);font-size:11px;color:var(--sr-text-muted)}
.meter .v{font-family:var(--font-data);font-size:11.5px;text-align:right;color:var(--dusk-50)}
.empty{border:1px dashed var(--border-strong);border-radius:var(--radius-card);padding:28px 24px;color:var(--sr-text-muted);display:flex;flex-direction:column;gap:8px;max-width:70ch}
.empty .t{font-family:var(--font-display);font-weight:700;font-size:20px;text-transform:uppercase;color:var(--sr-ink-on-dark)}
.gap{fill:rgba(232,178,58,.12)}
.k-stale{color:var(--sr-buoy)} .k-bad{color:#F0806A} .k-ok{color:var(--sr-starboard)}
.mini{font-size:12px;color:var(--sr-text-dim)}
.src-run{display:flex;gap:3px;align-items:flex-end;height:22px}.src-run i{flex:1;border-radius:2px;min-width:4px;height:100%}
.src-run i.completed{background:var(--sr-starboard)}.src-run i.completed_with_errors{background:var(--sr-buoy)}.src-run i.failed{background:#D9573F}.src-run i.running{background:var(--dusk-300)}
</style>
"""

body = r"""
<div class="shell">
  <aside class="side">
    <div class="brand">
      <svg width="24" height="24" viewBox="0 0 100 100" aria-hidden="true"><defs><clipPath id="mk"><path d="M59 14 L34 76 L68 76 C 85 52 80 28 59 14 Z"/></clipPath></defs><path d="M60 8 L30 80 L70 80 C 90 52 84 24 60 8 Z" fill="#F3F1EC"/><g clip-path="url(#mk)"><line x1="8" y1="40" x2="98" y2="40" stroke="#FF4119" stroke-width="9"/><line x1="8" y1="66" x2="98" y2="66" stroke="#0C5F5C" stroke-width="10"/></g></svg>
      <div class="wm">SAIL<b>RATINGS</b></div><span class="pill marine env">Admin</span>
    </div>
    <nav class="zone"><div class="label">Overview</div><button class="nav active" data-go="overview"><span class="glyph">◆</span>Today</button></nav>
    <nav class="zone"><div class="label">Data quality</div>
      <button class="nav" data-go="dupes"><span class="glyph">≈</span>Duplicate boats<span class="count hot" id="cnt-dupes"></span></button>
      <button class="nav" data-go="merges"><span class="glyph">↔</span>Merge history</button>
      <button class="nav" data-go="corrections"><span class="glyph">±</span>Corrections<span class="count">0</span></button>
      <button class="nav" data-go="health"><span class="glyph">▤</span>Data health</button>
      <button class="nav" data-go="tables"><span class="glyph">▦</span>Tables</button></nav>
    <nav class="zone"><div class="label">Operations</div>
      <button class="nav" data-go="scrapers"><span class="glyph">↻</span>Scrapers<span class="count hot" id="cnt-stale"></span></button>
      <button class="nav" data-go="sources"><span class="glyph">§</span>Sources &amp; policy</button>
      <button class="nav" data-go="firecrawl"><span class="glyph">⌁</span>Firecrawl</button></nav>
    <nav class="zone"><div class="label">Customers</div>
      <button class="nav" data-go="orders"><span class="glyph">£</span>Reports &amp; orders<span class="count">10</span></button>
      <button class="nav" data-go="users"><span class="glyph">@</span>Users &amp; plans</button>
      <button class="nav" data-go="billing"><span class="glyph">§</span>Stripe &amp; pricing</button></nav>
    <nav class="zone"><div class="label">Agents</div>
      <button class="nav" data-go="chat"><span class="glyph">›</span>Data chat</button></nav>
    <div class="foot"><div class="who">Stuart McLeod</div><div class="label" style="letter-spacing:0.1em;text-transform:none">dev · irc_data @ 5433</div></div>
  </aside>
  <div class="main">
    <div class="topbar">
      <label class="search"><span class="data" style="font-size:12px">⌕</span><input placeholder="Boat, sail number, cluster, run id…" aria-label="Search"><kbd>/</kbd></label>
      <div class="right"><span class="sample" style="color:var(--dusk-200);border-color:rgba(169,156,230,.5)">DB snapshot · 2 Sep 2026 16:27 BST</span><span class="pill ok"><i class="dot"></i>sailsys live</span><span class="pill warn"><i class="dot"></i>nightly stale</span></div>
    </div>
    <div class="content" id="content"></div>
  </div>
</div>
<div class="toast" id="toast"></div>
<script>
const DATA = __DATA__;
const $=s=>document.querySelector(s);
const fmt=n=>n==null?'—':Number(n).toLocaleString('en-GB');
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const statusPill=s=>({completed:'<span class="pill ok">ok</span>',completed_with_errors:'<span class="pill warn">errors</span>',failed:'<span class="pill bad">failed</span>',running:'<span class="pill info">running</span>'})[s]||'<span class="pill">'+esc(s)+'</span>';
const stalePill=d=>d===0?'<span class="pill ok"><i class="dot"></i>today</span>':d<=2?'<span class="pill ok">'+d+'d</span>':d<=7?'<span class="pill warn">'+d+'d stale</span>':'<span class="pill bad">'+d+'d stale</span>';
const runbars=arr=>'<div class="src-run">'+arr.map(s=>'<i class="'+s+'"></i>').join('')+'</div>';
const srcName={sailsys:'SailSys results',orc_api:'ORC certificates',topyacht:'TopYacht results',rhkyc:'RHKYC results',isora:'ISORA results',sailracehq:'SailRaceHQ results',cowesweek:'Cowes Week',rorc:'RORC results',sydneyhobart:'Sydney–Hobart',sailsys_json_import:'SailSys JSON import'};
const pageHead=(k,t,sub,right='')=>`<div class="pagehead"><div><div class="label">${k}</div><h1 class="h-page" style="margin-top:6px">${t}</h1><p class="sub">${sub}</p></div>${right}</div>`;
const stale=DATA.sources.filter(s=>s.stale>7&&!['sailsys_json_import','cowesweek','sydneyhobart','rorc'].includes(s.source));
const nightly=DATA.sources.filter(s=>['orc_api','topyacht'].includes(s.source));

function spark(series){const w=600,h=48,m=Math.max(...series.map(x=>x[1]),1);const pts=series.map((x,i)=>[i*(w/(series.length-1)),h-2-(x[1]/m)*(h-8)]);
  const gaps=[];let st=null;series.forEach((x,i)=>{if(x[1]===0&&st===null)st=i;if(x[1]>0&&st!==null){gaps.push([st,i-1]);st=null}});if(st!==null)gaps.push([st,series.length-1]);
  return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-label="Ingestion runs per day, 60 days">${gaps.filter(g=>g[1]-g[0]>=3).map(g=>`<rect class="gap" x="${g[0]*(w/(series.length-1))}" y="0" width="${(g[1]-g[0])*(w/(series.length-1))}" height="${h}"/>`).join('')}<path d="M${pts.map(p=>p.join(',')).join(' L')}" fill="none" stroke="#A99CE6" stroke-width="1.5"/></svg>`}

const S={};
S.overview=()=>{const t=DATA.today,q=DATA.qstats,orc=DATA.sources.find(s=>s.source==='orc_api');
  const gapDays=DATA.series.filter(x=>x[1]===0).length;
  return pageHead('Wednesday 2 September 2026','What needs a human today','Read from the live dev database at 16:27. Ranked by what is blocking published data.',
    `<button class="btn secondary" data-go="scrapers">Scrapers →</button>`)+
  `<div class="grid g4">
    <div class="card stat attn"><span class="label">Nightly scrapes</span><div class="v">${orc.stale}<small>days stale</small></div><div class="d">ORC and TopYacht last ran ${orc.last.slice(0,10)}. Only SailSys is running.</div></div>
    <div class="card stat attn"><span class="label">Duplicate boats</span><div class="v">${q.pending_clusters}<small>clusters</small></div><div class="d">${q.pending} rows pending · ${q.tiers.B} tier B, ${q.tiers.D} tier D</div></div>
    <div class="card stat"><span class="label">SailSys today</span><div class="v">${t.runs}<small>runs</small></div><div class="d">${fmt(t.found)} rows seen, <span class="k-stale">${t.new} new</span> · ${t.status.completed_with_errors} with errors</div></div>
    <div class="card stat"><span class="label">Corrections</span><div class="v">0</div><div class="d">Table is empty — public form has never been used</div></div>
  </div>
  <div class="grid g-3-2">
    <div class="card"><div class="sechead"><h2 class="h-section">Attention</h2><a class="more" href="#" data-go="scrapers">All sources →</a></div><div class="list">
      <div class="li"><span class="pill bad"><i class="dot"></i>Stale</span><div class="t"><div class="a">Nightly ORC certificate scrape has not run since ${orc.last.slice(0,10)}</div><div class="b">Last run found ${fmt(orc.found)} certs, ${orc.new} new, ${orc.dur}s. ${stale.length} sources have gone quiet since late July — matches the crontab/Temporal cutover in HANDOFF.md.</div></div><span class="when">${orc.stale}d</span></div>
      <div class="li"><span class="pill warn"><i class="dot"></i>Yield</span><div class="t"><div class="a">SailSys: ${t.runs} runs today, ${fmt(t.found)} rows found, 0 new</div><div class="b">${t.status.completed_with_errors} of ${t.runs} completed with errors. Either nothing new was raced or the incremental cursor is stuck.</div></div><span class="when">16:15</span></div>
      <div class="li"><span class="pill warn"><i class="dot"></i>Queue</span><div class="t"><div class="a">${q.pending_clusters} duplicate-boat clusters waiting for a verdict</div><div class="b">Queue built by the sail-number merge script; ${q.auto} rows auto-resolved, none reviewed by a person yet.</div></div><span class="when" data-go="dupes">open →</span></div>
      <div class="li"><span class="pill info"><i class="dot"></i>Gap</span><div class="t"><div class="a">${gapDays} of the last 60 days had no ingestion runs at all</div><div class="b">Nothing ran between 27 July and 1 September.</div></div><span class="when">60d</span></div>
      <div class="li"><span class="pill"><i class="dot"></i>Unused</span><div class="t"><div class="a">Six monitoring tables exist but are empty</div><div class="b">source_incidents, source_runs, watchdog_alerts, fact_assertions, raw_objects, retrieval_events — the monitoring layer is built but not wired.</div></div><span class="when" data-go="health">health →</span></div>
    </div></div>
    <div class="card"><div class="sechead"><h2 class="h-section">Sources</h2><a class="more" href="#" data-go="scrapers">Detail →</a></div>
      <div class="tablewrap" style="border:0;background:none"><table><thead><tr><th>Source</th><th>Last run</th><th class="num">Runs</th><th>State</th></tr></thead><tbody>
      ${DATA.sources.map(s=>`<tr><td>${esc(srcName[s.source]||s.source)}</td><td class="data dim">${s.last.slice(0,10)}</td><td class="num data">${fmt(s.n)}</td><td>${stalePill(s.stale)}</td></tr>`).join('')}
      </tbody></table></div></div>
  </div>
  <div class="grid g3">
    <div class="card"><div class="sechead"><h2 class="h-section">Runs per day</h2><span class="label">60 days</span></div>${spark(DATA.series)}<div class="note">Amber band = consecutive days with zero runs.</div></div>
    <div class="card"><div class="sechead"><h2 class="h-section">Boats</h2><span class="label">boats table</span></div><div class="stat" style="padding:0"><div class="v">${fmt(DATA.boats.total)}</div><div class="d">${fmt(DATA.census.find(c=>c.table_name==='boat_identities').rows)} identity observations · ${fmt(DATA.merges.total)} merges applied since ${DATA.merges.first}</div></div></div>
    <div class="card"><div class="sechead"><h2 class="h-section">Completeness</h2><span class="label">boats sample n=${DATA.boats.sample}</span></div><div class="meter">${['design','country','year_built','loa'].map(k=>`<span class="k">${k}</span><div class="bar"><i style="width:${100-DATA.boats.nulls[k]}%"></i></div><span class="v">${100-DATA.boats.nulls[k]}%</span>`).join('')}</div></div>
  </div>`};

S.dupes=()=>{const q=DATA.qstats;
  return pageHead('Data quality','Duplicate boats',`${q.pending_clusters} clusters (${q.pending} boat rows) the merge script would not auto-resolve. Tier B: same design, close year, same country. Tier D: ambiguous. Choose the canonical boat; the others merge into it and their identities, results and certificates move across.`,
   `<div style="display:flex;gap:8px"><button class="btn secondary sm">Export CSV</button><button class="btn secondary sm">Re-run merge script</button></div>`)+
  `<div class="chips" id="dfilters"><button class="chip on" data-f="all">All · ${q.pending_clusters}</button><button class="chip" data-f="tier:B">Tier B · ${q.tiers.B}</button><button class="chip" data-f="tier:D">Tier D · ${q.tiers.D}</button><span style="width:12px"></span>
    ${Object.entries(q.sizes).sort().map(([k,v])=>`<button class="chip" data-f="size:${k}">${k} boats · ${v}</button>`).join('')}<span style="width:12px"></span>
    ${q.countries.slice(0,4).map(([k,v])=>`<button class="chip" data-f="country:${k}">${k} · ${v}</button>`).join('')}</div>
  <div class="queue" id="queue">${DATA.clusters.slice(0,40).map(cluster).join('')}</div>
  <div class="note" id="qnote">Showing 40 of ${q.pending_clusters}. Verdicts write to dupe_review_queue (verdict, verdict_note, reviewed_by, reviewed_at); merges to boat_merges; rejections to boat_not_dupe with a reason.</div>`};

function cluster(c){const lead=c.boats[0];
  return `<article class="card cluster" data-tier="${c.tier}" data-size="${c.size}" data-country="${esc(c.country||'—')}" style="--n:${c.boats.length}">
    <div class="head"><span class="tier ${c.tier}">Tier ${c.tier}</span><span class="key">${esc(c.id)}</span><span class="why">${esc(c.why.replace(/_/g,' '))}</span></div>
    <div class="boats">${c.boats.map((b,i)=>`<div class="boat ${i===0?'lead':''}"><span class="id">boats/${b.id}${i===0?' · most evidence':''}</span><div class="name" title="${esc(b.name)}">${esc(b.name)}</div>
      <dl class="kv"><dt>Sail no</dt><dd>${esc(b.sail||'—')}</dd><dt>Design</dt><dd class="${b.design&&c.boats.every(x=>x.design===b.design)?'same':''}">${esc(b.design||'—')}</dd><dt>Country</dt><dd>${esc(b.country||'—')}</dd><dt>Year</dt><dd>${b.year||'—'}</dd><dt>Results</dt><dd class="${b.res?'':'diff'}">${fmt(b.res)}</dd><dt>Certs</dt><dd class="${b.certs?'same':''}">${b.certs}</dd><dt>Last seen</dt><dd>${b.last||'—'}</dd>${b.owner?`<dt>Owner</dt><dd>${esc(b.owner)}</dd>`:''}</dl>
      <button class="btn ${i===0?'primary':'secondary'} sm" data-act="merge" data-into="${b.id}" style="margin-top:auto">Merge into this</button></div>`).join('')}</div>
    <div class="foot"><span class="hint">${c.boats.reduce((a,b)=>a+b.res,0)} race results and ${c.boats.reduce((a,b)=>a+b.certs,0)} certificates across ${c.boats.length} records.</span>
      <select data-reason><option value="design_conflict">design conflict</option><option value="year_conflict">year conflict</option><option value="big_cluster_distinct">distinct boats</option><option value="other">other</option></select>
      <button class="btn secondary sm" data-act="notdupe">Not duplicates</button><button class="btn ghost sm" data-act="skip">Skip</button></div></article>`}

S.merges=()=>{const m=DATA.merges,n=DATA.notdupe;
  return pageHead('Data quality','Merge history',`${fmt(m.total)} boat merges applied between ${m.first} and ${m.last} (all by script), and ${n.total} clusters marked not-duplicate.`)+
  `<div class="grid g4"><div class="card stat"><span class="label">Merges</span><div class="v">${fmt(m.total)}</div><div class="d">${Object.entries(m.bymonth).map(([k,v])=>k+': '+v).join(' · ')} (sample)</div></div>
   <div class="card stat"><span class="label">Not duplicates</span><div class="v">${n.total}</div><div class="d">${Object.entries(n.reasons).map(([k,v])=>k.replace(/_/g,' ')+' '+v).join(' · ')}</div></div>
   <div class="card stat"><span class="label">By a person</span><div class="v">0</div><div class="d">reviewed_by is null on every row</div></div>
   <div class="card stat"><span class="label">Reversible</span><div class="v">—</div><div class="d">No unmerge path yet; loser rows are gone</div></div></div>
  <div class="grid g2"><div class="card"><div class="sechead"><h2 class="h-section">Recent merges</h2><span class="label">boat_merges</span></div><div class="tablewrap" style="border:0;background:none"><table><thead><tr><th>When</th><th>Cluster</th><th class="num">Winner</th><th class="num">Loser</th></tr></thead><tbody>
    ${m.recent.map(r=>`<tr><td class="data dim">${r.at}</td><td class="data">${esc(r.key)}</td><td class="num data">${r.w}</td><td class="num data dim">${r.l}</td></tr>`).join('')}</tbody></table></div></div>
  <div class="card"><div class="sechead"><h2 class="h-section">Recent not-duplicate</h2><span class="label">boat_not_dupe</span></div><div class="tablewrap" style="border:0;background:none"><table><thead><tr><th>When</th><th>Cluster</th><th>Boats</th><th>Reason</th></tr></thead><tbody>
    ${n.recent.map(r=>`<tr><td class="data dim">${r.at}</td><td class="data">${esc(r.key)}</td><td class="data dim">${r.ids.join(', ')}</td><td><span class="pill">${esc(r.reason.replace(/_/g,' '))}</span></td></tr>`).join('')}</tbody></table></div></div></div>`};

S.scrapers=()=>pageHead('Operations','Scrapers',`Per-source ingestion from ingestion_log (${fmt(DATA.census.find(c=>c.table_name==='ingestion_log').rows)} runs since 14 March). Bars are the last 14 runs, newest on the right.`,`<button class="btn secondary sm">Run nightly now</button>`)+
  `<div class="grid g3">${DATA.sources.map(s=>`<div class="card" ${s.stale>7?'style="border-color:rgba(232,178,58,.35)"':''}><div class="sechead"><h2 class="h-section">${esc(srcName[s.source]||s.source)}</h2>${stalePill(s.stale)}</div>${runbars(s.last14)}
    <dl class="kv" style="margin-top:14px"><dt>Last run</dt><dd>${s.last}${s.dur!=null?' · '+s.dur+'s':''}</dd><dt>Status</dt><dd>${statusPill(s.status)}</dd><dt>Found / new</dt><dd>${fmt(s.found)} / ${fmt(s.new)}</dd><dt>Runs</dt><dd>${fmt(s.n)}</dd>${s.lastfail?`<dt>Last fail</dt><dd class="diff" title="${esc(s.lastfail[1])}">${s.lastfail[0]} ${esc(s.lastfail[1].slice(0,28))}</dd>`:''}</dl>
    <div class="row-act" style="margin-top:12px"><button class="btn ghost sm">Runs</button><button class="btn secondary sm">Run now</button></div></div>`).join('')}</div>
  <div class="card"><div class="sechead"><h2 class="h-section">Today · SailSys</h2><span class="label">${DATA.today.runs} runs</span></div><p class="note" style="margin:0">${DATA.today.status.completed} completed, ${DATA.today.status.completed_with_errors} completed with errors, ${fmt(DATA.today.found)} rows found, ${DATA.today.new} new. Error messages are empty strings on every errored run — the scraper is not recording what went wrong.</p></div>`;

S.health=()=>{const c=DATA.census,empty=c.filter(x=>x.rows===0),b=DATA.boats;
  return pageHead('Data quality','Data health','Row counts from pg_stat, completeness from a 600-row sample of boats, and the tables that exist but have never been written to.')+
  `<div class="grid g-3-2"><div class="card"><div class="sechead"><h2 class="h-section">Completeness · boats</h2><span class="label">% populated</span></div><div class="meter">${Object.entries(b.nulls).map(([k,v])=>`<span class="k">${k}</span><div class="bar"><i style="width:${100-v}%;${100-v<40?'background:var(--sr-buoy)':''}"></i></div><span class="v">${100-v}%</span>`).join('')}</div>
    <p class="note" style="margin-top:14px">lwl is never populated; loa, displacement, builder, designer and year are ~80% empty. design is missing on ${b.nulls.design}% — which is also why so many duplicate clusters are "ambiguous".</p></div>
  <div class="card"><div class="sechead"><h2 class="h-section">Built, never written</h2><span class="label">${empty.length} tables</span></div><div class="list">${empty.map(x=>`<div class="li"><div class="t"><div class="a data" style="font-size:12.5px">${x.table_name}</div></div><span class="pill">0 rows</span></div>`).join('')}</div></div></div>
  <div class="card"><div class="sechead"><h2 class="h-section">Events</h2><span class="label">${fmt(DATA.events.total)} rows</span></div><p class="note" style="margin:0 0 8px">venue is null on ${DATA.events.venue_null} of ${DATA.events.sample} sampled events. Top organisers: ${DATA.events.organisers.map(([k,v])=>k+' '+v).join(', ')}. Names arrive raw from SailSys, e.g.</p>${DATA.events.messy.map(n=>`<div class="sql" style="margin-bottom:6px">${esc(n)}</div>`).join('')}</div>`};

S.tables=()=>pageHead('Data quality','Tables',`${DATA.census.length} tables in irc_data. Sizes and counts from pg_stat at snapshot time. Edits go through admin_edits (${DATA.census.find(c=>c.table_name==='admin_edits').rows} so far).`)+
  `<div class="tablewrap"><table><thead><tr><th>Table</th><th class="num">Rows</th><th class="num">Size</th><th></th></tr></thead><tbody>${DATA.census.map(c=>`<tr><td class="data">${c.table_name}</td><td class="num data">${fmt(c.rows)}</td><td class="num data dim">${c.size}</td><td><div class="row-act"><button class="btn ghost sm">Open →</button></div></td></tr>`).join('')}</tbody></table></div>`;

S.corrections=()=>pageHead('Data quality','Corrections','Public boat-page submissions for designer, builder, year_built, design_canonical or a new design class.')+
  `<div class="empty"><div class="t">Nothing submitted yet</div><div>boat_corrections has 0 rows. The endpoint and the approve/reject flow exist in the API; the public form has either not shipped or nobody has found it. When rows arrive they will appear here with a before/after diff and an approve button.</div></div>`;

S.sources=()=>pageHead('Operations','Sources & policy','data_sources holds 11 registered sources with slug, category, adapter, policy_version, legal_status, robots_checked_at, enabled and cadence. The rows were not in this export.')+
  `<div class="empty"><div class="t">11 sources registered</div><div>Columns present in schema: display_name, base_url, category, adapter_class, policy_version (default interim-v0), legal_status (default approved), robots_checked_at, robots_disallow, contact_email, enabled, cadence. source_schedule_state (11 rows) holds the Temporal schedule id and paused flag per source — that is the switch this page should expose.</div></div>`;

S.firecrawl=()=>{const f=DATA.fc;return pageHead('Operations','Firecrawl',`${fmt(f.total)} calls logged. The most recent ${f.sample} (all ${f.last}) were the news scraper against ${f.domains[0][0]}, one credit each, ${f.avg_ms}ms average.`)+
  `<div class="grid g4"><div class="card stat"><span class="label">Calls</span><div class="v">${fmt(f.total)}</div></div><div class="card stat"><span class="label">Credits · sample</span><div class="v">${f.credits}</div></div><div class="card stat"><span class="label">Avg duration</span><div class="v">${f.avg_ms}<small>ms</small></div></div><div class="card stat"><span class="label">Last call</span><div class="v" style="font-size:20px">${f.last}</div><div class="d">38 days ago — stopped with the nightly jobs</div></div></div>`};

const money=(a,c)=>new Intl.NumberFormat('en-GB',{style:'currency',currency:c.toUpperCase()}).format(a/100);
S.orders=()=>{const st=DATA.stripe,ss=st.sessions,paid=ss.filter(x=>x.paid),real=paid.filter(x=>x.total>0),free=paid.filter(x=>x.total===0),exp=ss.filter(x=>!x.paid);
  return pageHead('Customers','Reports & orders',`Live Stripe account ${st.name}: ${ss.length} checkout sessions since 21 March. ${real.length} paid, ${free.length} completed with the 100% BETASAIL code, ${exp.length} expired unpaid. The database has 47 order rows — 37 more than Stripe knows about, so most were created at checkout-button click and never reached Stripe.`)+
  `<div class="grid g4"><div class="card stat"><span class="label">Revenue · all time</span><div class="v">${money(9900,'usd')}</div><div class="d">1 charge · ${st.charges[0].created.slice(0,10)} · balance ${money(st.balance_gbp,'gbp')}</div></div>
   <div class="card stat"><span class="label">Checkout → paid</span><div class="v">${real.length}<small>/ ${ss.length}</small></div><div class="d">${Math.round(100*real.length/ss.length)}% paid · ${Math.round(100*paid.length/ss.length)}% completed incl. beta code</div></div>
   <div class="card stat"><span class="label">Beta reports</span><div class="v">${free.length}</div><div class="d">BETASAIL · ${st.promo.redeemed} of ${st.promo.max} redemptions</div></div>
   <div class="card stat attn"><span class="label">Expired at checkout</span><div class="v">${exp.length}</div><div class="d">Opened, never paid — ${money(exp.reduce((a,x)=>a+(x.cur==='usd'?x.total:x.cur==='gbp'?x.total*1.27:x.total*0.65),0),'usd')} approx.</div></div></div>
  <div class="tablewrap"><table><thead><tr><th>Created</th><th>Session</th><th>Boat</th><th class="num">List</th><th class="num">Paid</th><th>Promo</th><th>Email</th><th>Status</th><th>Report</th><th></th></tr></thead><tbody>
  ${ss.map(x=>`<tr><td class="data dim">${x.created}</td><td class="data dim">${x.id}</td><td><a href="#">boats/${x.boat}</a></td><td class="num data">${money(x.subtotal,x.cur)}</td><td class="num data ${x.total>0&&x.paid?'k-ok':''}">${x.paid?money(x.total,x.cur):'—'}</td><td>${x.promo?'<span class="pill dusk">'+x.promo+'</span>':''}</td><td class="data dim">${x.email||'—'}</td><td>${x.paid?'<span class="pill ok">paid</span>':'<span class="pill">expired</span>'}</td><td class="data dim">${x.token}…</td><td><div class="row-act">${x.paid?'<button class="btn ghost sm">PDF</button><button class="btn ghost sm">Regenerate</button>':'<button class="btn ghost sm">Recover</button>'}</div></td></tr>`).join('')}</tbody></table></div>
  <div class="card"><div class="sechead"><h2 class="h-section">Worth fixing</h2><span class="label">from the Stripe account</span></div><div class="list">
    <div class="li"><span class="pill warn">Descriptor · Dashboard</span><div class="t"><div class="a">The one real charge appeared on the card as "${st.charges[0].descriptor}"</div><div class="b">Statement descriptor is inherited from the account and is not SailRatings. Set it on the account or per checkout session.</div></div></div>
    <div class="li"><span class="pill warn">Branding · Dashboard</span><div class="t"><div class="a">Checkout page displays "${st.branding}"</div><div class="b">Checkout branding_settings.display_name is the legal entity, not the product. Logo and colours are Stripe defaults (#0074d4).</div></div></div>
    <div class="li"><span class="pill info">Pricing</span><div class="t"><div class="a">Catalogue price is ${money(6900,'gbp')}; checkouts charged $99 / £79 / A$149</div><div class="b">Prices are computed in web/src/lib/currency.ts at checkout time and passed as ad-hoc line items; the Stripe product is not what customers pay.</div></div></div>
    <div class="li"><span class="pill info">Customers</span><div class="t"><div class="a">customer_creation is "if_required" — no Stripe customer objects exist</div><div class="b">Every buyer is a guest. Subscriptions will need real customers, so switch to "always" before Pro launches.</div></div></div>
  </div></div>`};

S.users=()=>{const st=DATA.stripe;
  return pageHead('Customers','Users & plans','What a customer is today: a checkout email. There are no accounts (Clerk sync pending), no Stripe customers, and no subscriptions. This page shows the plan structure the business plan calls for, against what Stripe holds now.')+
  `<div class="grid g4"><div class="card stat"><span class="label">Stripe customers</span><div class="v">${st.customers}</div><div class="d">customer_creation: if_required</div></div><div class="card stat"><span class="label">Subscriptions</span><div class="v">${st.subscriptions}</div><div class="d">No recurring prices exist</div></div><div class="card stat"><span class="label">Distinct buyer emails</span><div class="v">${new Set(st.sessions.filter(x=>x.email).map(x=>x.email)).size}</div><div class="d">from checkout sessions</div></div><div class="card stat"><span class="label">Clerk accounts</span><div class="v">—</div><div class="d">Not synced to Postgres yet</div></div></div>
  <div class="grid g2"><div class="card"><div class="sechead"><h2 class="h-section">People who have paid or redeemed</h2><span class="label">checkout emails</span></div><div class="tablewrap" style="border:0;background:none"><table><thead><tr><th>Email</th><th class="num">Sessions</th><th class="num">Paid</th><th>Boats</th><th>Last</th></tr></thead><tbody>
    ${Object.values(st.sessions.filter(x=>x.email).reduce((m,x)=>{(m[x.email]=m[x.email]||{email:x.email,n:0,paid:0,boats:new Set(),last:''});m[x.email].n++;if(x.total>0&&x.paid)m[x.email].paid+=x.total;m[x.email].boats.add(x.boat);m[x.email].last=m[x.email].last||x.created;return m},{})).map(u=>`<tr><td class="data">${u.email}</td><td class="num data">${u.n}</td><td class="num data ${u.paid?'k-ok':''}">${u.paid?money(u.paid,'usd'):'—'}</td><td class="data dim">${[...u.boats].join(', ')}</td><td class="data dim">${u.last.slice(0,10)}</td></tr>`).join('')}</tbody></table></div>
    <p class="note" style="margin-top:12px">All three are beta testers using BETASAIL; the only paying customer also redeemed it later.</p></div>
  <div class="card"><div class="sechead"><h2 class="h-section">Plans</h2><span class="label">business plan vs Stripe</span></div><div class="tablewrap" style="border:0;background:none"><table><thead><tr><th>Plan</th><th>Planned</th><th>In Stripe</th><th></th></tr></thead><tbody>
    <tr><td>Premium Ratings Report</td><td class="data">$75–100/ft one-off</td><td class="data">${money(6900,'gbp')} one-time (catalogue) · ad-hoc at checkout</td><td><span class="pill ok">live</span></td></tr>
    <tr><td>Pro monthly</td><td class="data">£12/mo</td><td class="data">£12.00/mo · pro_monthly_gbp</td><td><span class="pill ok">created 2 Sep</span></td></tr>
    <tr><td>Pro annual</td><td class="data">£96/yr</td><td class="data">£96.00/yr · pro_annual_gbp</td><td><span class="pill ok">created 2 Sep</span></td></tr>
    <tr><td>Team / Club</td><td class="data">£120/mo</td><td class="data dim">—</td><td><span class="pill">not created</span></td></tr>
    <tr><td>Enterprise API</td><td class="data">£500–2,000/mo</td><td class="data dim">—</td><td><span class="pill">not created</span></td></tr></tbody></table></div>
    <div class="row-act" style="margin-top:12px;justify-content:flex-start"><button class="btn secondary sm">Create Team / Club price</button></div></div></div>
  <div class="empty"><div class="t">To make this page real</div><div>1. Clerk → Postgres user sync (in progress in Notion). 2. Stripe customer_creation "always" and store stripe_customer_id on the user. 3. Recurring prices for Pro/Team. 4. A webhook for customer.subscription.* into a subscriptions table. Then this page lists users with plan, boats claimed and last seen.</div></div>`};

S.billing=()=>{const st=DATA.stripe;return pageHead('Customers','Stripe & pricing',`Account ${st.account} (${st.name}), live mode. Read straight from the Stripe API.`)+
  `<div class="grid g4"><div class="card stat"><span class="label">Balance</span><div class="v">${money(st.balance_gbp,'gbp')}</div><div class="d">available · pending ${money(0,'gbp')}</div></div><div class="card stat"><span class="label">Products</span><div class="v">${st.products.length}</div><div class="d">${st.products[0].name}</div></div><div class="card stat"><span class="label">Promotion codes</span><div class="v">1</div><div class="d">${st.promo.code} · ${st.promo.percent}% off · ${st.promo.redeemed}/${st.promo.max}</div></div><div class="card stat"><span class="label">Charges</span><div class="v">${st.charges.length}</div><div class="d">${money(9900,'usd')} · ${st.charges[0].created.slice(0,10)}</div></div></div>
  <div class="grid g2"><div class="card"><div class="sechead"><h2 class="h-section">Catalogue</h2><span class="label">products · prices</span></div><div class="tablewrap" style="border:0;background:none"><table><thead><tr><th>Product</th><th>Price id</th><th class="num">Amount</th><th>Type</th><th>Created</th></tr></thead><tbody>${st.products.map(p=>`<tr><td>${p.name}</td><td class="data dim">${p.price}</td><td class="num data">${money(p.amount,p.cur)}</td><td><span class="pill ${p.type.startsWith('recurring')?'ok':''}">${p.type.replace('_',' ')}</span></td><td class="data dim">${p.created}</td></tr>`).join('')}</tbody></table></div></div>
  <div class="card"><div class="sechead"><h2 class="h-section">Charges</h2><span class="label">live</span></div><div class="tablewrap" style="border:0;background:none"><table><thead><tr><th>Charge</th><th class="num">Amount</th><th>Card</th><th>Email</th><th>Status</th></tr></thead><tbody>${st.charges.map(c=>`<tr><td class="data dim">${c.id.slice(0,14)}…</td><td class="num data k-ok">${money(c.amount,c.cur)}</td><td class="data dim">${c.card}</td><td class="data dim">${c.email}</td><td><span class="pill ok">${c.status}</span></td></tr>`).join('')}</tbody></table></div>
    <p class="note" style="margin-top:12px">Descriptor on the customer's statement: <span class="data">${st.charges[0].descriptor}</span></p></div></div>`};

S.chat=()=>{const c=DATA.chat;return pageHead('Agents','Data chat',`${c.convs} conversations, ${c.msgs} messages between ${c.first} and ${c.last}. ${c.queries} messages ran queries and ${c.changes} proposed SQL changes — but admin_edits has only 5 rows, so most proposals were rejected or never confirmed.`)+
  `<div class="grid g4"><div class="card stat"><span class="label">Conversations</span><div class="v">${c.convs}</div></div><div class="card stat"><span class="label">Messages</span><div class="v">${c.msgs}</div></div><div class="card stat"><span class="label">Ran queries</span><div class="v">${c.queries}</div></div><div class="card stat"><span class="label">Proposed changes</span><div class="v">${c.changes}<small>5 applied</small></div></div></div>
  <div class="empty"><div class="t">Last used ${c.last}</div><div>The chat UI itself carries over from the existing /admin page — SSE stream, proposed change cards, confirm/execute. It gets the new shell and styling, not a rebuild.</div></div>`};

function render(id){const c=$('#content');c.innerHTML='<section class="screen on">'+(S[id]||S.overview)()+'</section>';document.querySelectorAll('.side .nav').forEach(n=>n.classList.toggle('active',n.dataset.go===id));window.scrollTo({top:0});try{history.replaceState(null,'','#'+id)}catch(e){}}
document.addEventListener('click',e=>{const g=e.target.closest('[data-go]');if(g){e.preventDefault();render(g.dataset.go);return}
  const b=e.target.closest('[data-act]');if(b){const card=b.closest('.cluster');const lead=card.querySelector('.boat.lead .name').textContent;
    const msg={merge:'Merged into boats/'+b.dataset.into+' · boat_merges + dupe_review_queue updated',notdupe:'Marked not duplicate ('+card.querySelector('[data-reason]').value.replace(/_/g,' ')+') · boat_not_dupe',skip:'Skipped'}[b.dataset.act];
    card.classList.add('gone');setTimeout(()=>card.remove(),250);if(b.dataset.act!=='skip'){DATA.qstats.pending_clusters--;$('#cnt-dupes').textContent=DATA.qstats.pending_clusters}say(msg);return}
  const ch=e.target.closest('#dfilters .chip');if(ch){document.querySelectorAll('#dfilters .chip').forEach(x=>x.classList.remove('on'));ch.classList.add('on');const [k,v]=ch.dataset.f.split(':');
    document.querySelectorAll('#queue .cluster').forEach(m=>{m.style.display=(k==='all'||m.dataset[k]===v)?'':'none'});return}
  const btn=e.target.closest('.btn');if(btn)say(btn.textContent.trim()+' — prototype only')});
const toast=$('#toast');let tt;function say(m){toast.textContent=m;toast.classList.add('show');clearTimeout(tt);tt=setTimeout(()=>toast.classList.remove('show'),2200)}
document.addEventListener('keydown',e=>{if(e.key==='/'&&document.activeElement.tagName!=='INPUT'){e.preventDefault();$('.search input').focus()}});
$('#cnt-dupes').textContent=DATA.qstats.pending_clusters;$('#cnt-stale').textContent=stale.length+' stale';
render((location.hash||'#overview').slice(1));
</script>
"""
out=head+style+extra_css+body.replace('__DATA__',data)
open(SRC,'w').write(out)
open('/tmp/claude-0/-home-claude/3d6b3780-45d8-5cd2-9972-1d08da93481c/scratchpad/preview.html','w').write('<!doctype html><html><head><meta charset="utf-8"><style>body{margin:0}</style></head><body>'+out+'</body></html>')
print(len(out))
