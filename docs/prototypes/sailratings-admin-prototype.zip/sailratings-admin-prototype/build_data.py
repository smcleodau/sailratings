import json, re, collections as C
from datetime import datetime as D, date
U='/mnt/user-data/uploads/sailratings-admin-export-20260902/'
def J(n): return json.load(open(U+n))
def P(s): return D.fromisoformat(re.sub(r'\.(\d+)\+',lambda m:'.'+m.group(1).ljust(6,'0')+'+',s))
TODAY=date(2026,9,2)

census=J('_census.json')
L=sorted(J('ingestion_log.json'),key=lambda r:r['started_at'])
by=C.defaultdict(list)
for r in L: by[r['source']].append(r)
sources=[]
for s,rs in by.items():
    last=rs[-1]
    dur=(P(last['completed_at'])-P(last['started_at'])).total_seconds() if last['completed_at'] else None
    stale=(TODAY-P(last['started_at']).date()).days
    fails=[r for r in rs if r['status']=='failed']
    sources.append(dict(source=s,n=len(rs),last=last['started_at'][:16].replace('T',' '),status=last['status'],found=last['records_found'],new=last['records_new'],dur=dur and round(dur),stale=stale,
        last14=[r['status'] for r in rs[-14:]],err=(last['error_message'] or '')[:120],lastfail=(fails[-1]['started_at'][:16].replace('T',' '),(fails[-1]['error_message'] or '')[:140]) if fails else None,
        new30=sum(r['records_new'] or 0 for r in rs if r['started_at']>='2026-08-03')))
sources.sort(key=lambda x:-x['n'])
today=[r for r in L if r['started_at'].startswith('2026-09-02')]
todayS=dict(runs=len(today),status=dict(C.Counter(r['status'] for r in today)),found=sum(r['records_found'] or 0 for r in today),new=sum(r['records_new'] or 0 for r in today),
    clubs=len({(r['error_message'] or '').split(':')[0] for r in today}))
# daily run counts last 60 days for a sparkline
days=C.Counter(r['started_at'][:10] for r in L)
from datetime import timedelta
series=[(str(TODAY-timedelta(days=i)),days.get(str(TODAY-timedelta(days=i)),0)) for i in range(59,-1,-1)]

q=J('dupe_review_queue.json')
cl=C.defaultdict(list)
for r in q: cl[r['cluster_id']].append(r)
clusters=[]
for k,v in cl.items():
    v=sorted(v,key=lambda x:-(x['race_results']+x['cert_count']*20))
    clusters.append(dict(id=k,tier=v[0]['tier'],why=v[0]['why'],size=v[0]['cluster_size'],verdict=v[0]['verdict'],country=v[0]['country'],
        boats=[dict(id=x['boat_id'],name=x['boat_name'],sail=x['sail_number'],country=x['country'],design=x['design'],year=x['year_built'],res=x['race_results'],certs=x['cert_count'],last=x['latest_activity'],owner=x['owner']) for x in v]))
pending=[c for c in clusters if c['verdict']=='PENDING']
pending.sort(key=lambda c:(c['tier'],-sum(b['res'] for b in c['boats'])))
qstats=dict(rows=len(q),pending=sum(1 for r in q if r['verdict']=='PENDING'),auto=sum(1 for r in q if r['verdict']!='PENDING'),clusters=len(clusters),pending_clusters=len(pending),
    tiers=dict(C.Counter(c['tier'] for c in pending)),sizes=dict(C.Counter(c['size'] for c in pending)),countries=C.Counter(c['country'] or '—' for c in pending).most_common(8))

m=J('boat_merges.json'); nd=J('boat_not_dupe.json')
merges=dict(total=1428,sample=len(m),first='2026-05-20',last='2026-07-26',recent=[dict(id=x['id'],at=x['merged_at'][:16].replace('T',' '),w=x['winner_id'],l=x['loser_id'],key=x['cluster_key']) for x in m[:25]],
    bymonth=dict(C.Counter(x['merged_at'][:7] for x in m)))
notdupe=dict(total=251,reasons=dict(C.Counter(x['reason'] for x in nd)),recent=[dict(at=x['marked_at'][:16].replace('T',' '),key=x['cluster_key'],ids=x['boat_ids'],reason=x['reason']) for x in nd[:12]])

b=J('boats_sample.json'); n=len(b)
nulls={k:round(100*sum(1 for r in b if r[k] in (None,''))/n) for k in ['design','design_canonical','country','year_built','builder','designer','loa','lwl','beam_max','displacement_kg']}
countries=C.Counter(r['country'] or '—' for r in b).most_common(10)
f=J('firecrawl_calls.json')
fc=dict(total=1145,sample=len(f),credits=sum(r['credits'] or 0 for r in f),domains=C.Counter(r['domain'] for r in f).most_common(5),last=max(r['called_at'] for r in f)[:10],avg_ms=round(sum(r['duration_ms'] or 0 for r in f)/len(f)))
a=J('admin_messages_meta.json')
chat=dict(convs=21,msgs=246,changes=sum(1 for r in a if r['has_changes']),queries=sum(1 for r in a if r['has_queries']),first=min(r['created_at'] for r in a)[:10],last=max(r['created_at'] for r in a)[:10])
e=J('events_sample.json')
events=dict(total=7805,organisers=C.Counter(r['organiser'] or '—' for r in e).most_common(8),venue_null=sum(1 for r in e if not r['venue']),sample=len(e),
    messy=[r['name'] for r in e if r['name']!=r['name'].strip() or '(' in r['name']][:5])

data=dict(census=census,sources=sources,today=todayS,series=series,clusters=pending,qstats=qstats,merges=merges,notdupe=notdupe,boats=dict(total=9567,sample=n,nulls=nulls,countries=countries),fc=fc,chat=chat,events=events)
json.dump(data,open('/home/claude/admin_data.json','w'),default=str)
print({k:(len(v) if hasattr(v,'__len__') else v) for k,v in data.items()})
print(json.dumps(sources[:3],indent=0)[:1500]); print(qstats); print(nulls)
